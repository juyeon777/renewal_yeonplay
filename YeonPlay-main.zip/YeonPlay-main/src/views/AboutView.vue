<template>
  <div class="about">
    <h1>About My Movie Site</h1>
    <p>This site was built using Vue.js and The Movie Database (TMDB) API.</p>
    <p>Explore popular and now-playing movies with detailed information.</p>
  </div>
</template>

<style>
.about {
  text-align: center;
  margin: 20px;
}

.about h1 {
  font-size: 2rem;
  color: #2c3e50;
}

.about p {
  font-size: 1.2rem;
  color: #333;
}
</style>
